def sharpe_ratio_allocation(expected_returns, risks, risk_free_rate, total_funds):
    sharpe_ratios = {asset: (expected_returns[asset] - risk_free_rate) / risks[asset] for asset in expected_returns}
    total_sharpe = sum(sharpe_ratios.values())
    
    allocations = {}
    for asset, sharpe in sharpe_ratios.items():
        allocations[asset] = (sharpe / total_sharpe) * total_funds
    
    return allocations

# Example usage:
expected_returns = {'AAPL': 0.10, 'GOOGL': 0.05, 'MSFT': 0.03}
risks = {'AAPL': 0.2, 'GOOGL': 0.1, 'MSFT': 0.05}
risk_free_rate = 0.02
total_funds = 10000
allocations = sharpe_ratio_allocation(expected_returns, risks, risk_free_rate, total_funds)
print(allocations)
