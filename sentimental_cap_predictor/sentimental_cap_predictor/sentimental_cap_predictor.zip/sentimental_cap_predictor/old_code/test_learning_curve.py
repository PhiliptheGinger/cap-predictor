import matplotlib.pyplot as plt
plt.plot([1, 2, 3], [4, 5, 6])
plt.savefig(r'D:\Programming Projects\CAP\CAP_PREDICTOR\learning_curve_test.png')
