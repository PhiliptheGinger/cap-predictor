import typer
from pathlib import Path
from loguru import logger
from datetime import datetime as dt
import time

from sentimental_cap_predictor.config import RAW_DATA_DIR, PROCESSED_DATA_DIR
from sentimental_cap_predictor.features import generate_predictions as feature_main
from sentimental_cap_predictor.dataset import download_ticker_from_yfinance, download_news_from_yfinance, handle_missing_data

app = typer.Typer()

# Hardcoded list of stock tickers
TICKER_LIST = [
    # Technology
    "AAPL", "GOOGL", "MSFT", "NVDA", "AMD",
    # Healthcare
    "JNJ", "PFE", "MRK", "UNH", "ABT",
    # Financials
    "JPM", "BAC", "GS", "WFC", "AXP",
    # Consumer Discretionary
    "TSLA", "AMZN", "NKE", "HD", "MCD",
    # Consumer Staples
    "PG", "KO", "PEP", "WMT", "COST",
    # Industrials
    "BA", "CAT", "UPS", "GE", "MMM"
]

def download_data(ticker: str):
    logger.info(f"Downloading data for ticker: {ticker}")

    # Set paths
    output_path = RAW_DATA_DIR / f"{ticker}.feather"
    news_output_path = RAW_DATA_DIR / f"{ticker}_news.feather"

    # Download stock data
    try:
        df = download_ticker_from_yfinance(ticker)  # Removed extra arguments
        df = handle_missing_data(df)
        df.reset_index(inplace=True)
        df.to_feather(output_path)
        logger.info(f"Data saved to {output_path}")
    except Exception as e:
        logger.error(f"Failed to download or save stock data for {ticker}: {e}")
        return None, None

    # Download news data
    try:
        start_date = df['date'].min().strftime('%Y-%m-%d')
        end_date = df['date'].max().strftime('%Y-%m-%d')
        news_df = download_news_from_yfinance(ticker, start_date, end_date)
        if not news_df.empty:
            news_df.to_feather(news_output_path)
            logger.info(f"News data saved to {news_output_path}")
        else:
            logger.warning(f"No news data available for {ticker} from {start_date} to {end_date}")
    except Exception as e:
        logger.error(f"Failed to download or save news data for {ticker}: {e}")
        return None, None

    return output_path, news_output_path

def analyze_data(ticker: str, processed_dir: Path):
    logger.info(f"Starting feature extraction for {ticker}.")
    try:
        feature_main(ticker)  # Call the feature extraction function
        logger.info(f"Feature extraction completed for {ticker}.")
    except Exception as e:
        logger.error(f"Failed to extract features for {ticker}: {e}")
        return

    logger.info(f"Completed processing for ticker: {ticker}")

@app.command()
def analyze_tickers(
    ticker: str = typer.Option(None, help="Specific ticker symbol to analyze. If not provided, will process all tickers."),
    batch: bool = typer.Option(False, help="Run in batch mode with default date range")
):
    start_time = time.time()
    logger.info("Starting stock analysis.")

    # Ensure processed directory exists
    if not PROCESSED_DATA_DIR.exists():
        logger.info(f"Processed directory does not exist. Creating: {PROCESSED_DATA_DIR}")
        PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)

    # Download data for specific ticker or all tickers
    data_paths = []
    if ticker:
        data_paths.append(download_data(ticker))
    else:
        for ticker in TICKER_LIST:
            data_paths.append(download_data(ticker))

    # Analyze the downloaded data
    for ticker, paths in zip(TICKER_LIST, data_paths):
        if paths[0] is not None:  # Ensure data was downloaded successfully
            analyze_data(ticker, PROCESSED_DATA_DIR)

    end_time = time.time()
    elapsed_time = end_time - start_time
    logger.info(f"Stock analysis completed in {elapsed_time:.2f} seconds.")

if __name__ == "__main__":
    app()
