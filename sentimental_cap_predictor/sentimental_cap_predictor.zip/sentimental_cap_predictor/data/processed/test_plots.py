import pandas as pd
import matplotlib.pyplot as plt

# File path to the CSV
file_path = r"D:\Programming Projects\CAP\sentimental_cap_predictor\sentimental_cap_predictor\data\processed\AAPL_final_predictions.csv"

# Load the CSV into a DataFrame
df = pd.read_csv(file_path)

# Print column names to verify
print("Columns in CSV:", df.columns)

# Assuming the 'date' column may have a different name, adjust accordingly
# Replace 'date' with the correct column name after inspecting the printed columns
date_column = 'date'  # Replace with the correct column name if different

# Convert the 'date' column to datetime
df[date_column] = pd.to_datetime(df[date_column])

# Plotting
plt.figure(figsize=(12, 8))

# Plot each column against the 'date' column
plt.plot(df[date_column], df['TrueValues'], label='True Values', color='green')
plt.plot(df[date_column], df['SARIMA'], label='SARIMA Predictions', color='blue')
plt.plot(df[date_column], df['DeepLearningPredictions'], label='Deep Learning Predictions', color='red')
plt.plot(df[date_column], df['BiasedPrediction'], label='Biased Prediction', color='orange')

# Set the title and labels
plt.title('AAPL Predictions Comparison Over Time')
plt.xlabel('Date')
plt.ylabel('Values')
plt.legend()

# Rotate x-axis labels for better readability
plt.xticks(rotation=45)

# Show the plot
plt.tight_layout()
plt.show()
