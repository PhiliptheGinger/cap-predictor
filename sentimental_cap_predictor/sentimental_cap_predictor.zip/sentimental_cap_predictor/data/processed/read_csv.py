import pandas as pd
from pathlib import Path
import typer
from loguru import logger

app = typer.Typer()

@app.command()
def read_csv_head(
    file_path: Path = typer.Argument(..., help="Path to the CSV file"),
    num_lines: int = typer.Option(5, help="Number of lines to read from the top of the CSV file"),
):
    """Reads and prints the first few lines of a CSV file."""
    try:
        # Load the data
        logger.info(f"Loading data from file: {file_path}")
        df = pd.read_csv(file_path)
        
        # Print the first few lines of the file
        logger.info(f"Displaying the first {num_lines} lines of the CSV file:")
        print(df.head(num_lines))
    except FileNotFoundError:
        logger.error(f"File not found: {file_path}")
    except pd.errors.EmptyDataError:
        logger.error("The file is empty.")
    except pd.errors.ParserError:
        logger.error("Error parsing the file. Ensure it is a valid CSV format.")
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    app()
