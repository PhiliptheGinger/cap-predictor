from sentimental_cap_predictor import config  # noqa: F401
