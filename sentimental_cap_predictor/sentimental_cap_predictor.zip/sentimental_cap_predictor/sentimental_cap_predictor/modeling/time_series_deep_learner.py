import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, RNN, Layer
from tensorflow.keras.optimizers import Adam
from tensorflow.keras import initializers, activations
from tensorflow.keras.regularizers import l2
from scipy.fftpack import fft
from statsmodels.graphics.tsaplots import plot_acf
import matplotlib.pyplot as plt
from tqdm import tqdm
from colorama import Fore, init
import warnings
import statsmodels.api as sm

# Initialize colorama
init(autoreset=True)

# Custom Liquid Time-Constant (LTC) Layer
class LiquidLayer(Layer):
    def __init__(self, units, **kwargs):
        super(LiquidLayer, self).__init__(**kwargs)
        self.units = units
        self.state_size = units

    def build(self, input_shape):
        self.kernel = self.add_weight(shape=(input_shape[-1], self.units),
                                      initializer=initializers.RandomNormal(),
                                      trainable=True)
        self.recurrent_kernel = self.add_weight(shape=(self.units, self.units),
                                                initializer=initializers.RandomNormal(),
                                                trainable=True)
        self.bias = self.add_weight(shape=(self.units,),
                                    initializer=initializers.Zeros(),
                                    trainable=True)
        self.built = True

    def call(self, inputs, states):
        prev_output = states[0]
        h = tf.matmul(inputs, self.kernel) + tf.matmul(prev_output, self.recurrent_kernel) + self.bias
        output = activations.tanh(h)
        return output, [output]

    def get_config(self):
        config = super(LiquidLayer, self).get_config()
        config.update({
            "units": self.units
        })
        return config

    @classmethod
    def from_config(cls, config):
        return cls(**config)

def create_rolling_window_sequences(data, window_size):
    """Generate rolling window sequences from time series data."""
    X, y = [], []
    for i in range(len(data) - window_size):
        X.append(data[i:i + window_size])
        y.append(data[i + window_size])
    return np.array(X), np.array(y)

def build_liquid_model(input_shape, learning_rate=0.001):
    model = Sequential()
    model.add(RNN(LiquidLayer(64), return_sequences=True, input_shape=input_shape))
    model.add(Dropout(0.2))
    model.add(RNN(LiquidLayer(64)))
    model.add(Dropout(0.2))
    model.add(Dense(16, activation='relu', kernel_regularizer=l2(0.01)))
    model.add(Dense(1))
    
    optimizer = Adam(learning_rate=learning_rate)
    model.compile(optimizer=optimizer, loss='mse')
    
    return model

def train_model_with_rolling_window(model, X_train, y_train, X_val=None, y_val=None, window_size=100, step_size=10, batch_size=64, epochs=10):
    total_windows = (len(X_train) - window_size) // step_size
    progress_bar = tqdm(total=total_windows, desc=Fore.GREEN + "Training Progress", ncols=100)

    for window_num, start_idx in enumerate(range(0, len(X_train) - window_size, step_size), start=1):
        end_idx = start_idx + window_size
        
        X_window_train = X_train[start_idx:end_idx]
        y_window_train = y_train[start_idx:end_idx]
        
        # Optionally pass validation data
        validation_data = (X_val, y_val) if X_val is not None and y_val is not None else None
        
        progress_bar.set_description(Fore.GREEN + f"Training Window {window_num}/{total_windows}")
        
        model.fit(X_window_train, y_window_train, validation_data=validation_data,
                  batch_size=batch_size, epochs=epochs, verbose=0)
        
        progress_bar.update(1)
    
    progress_bar.close()
    return model

def perform_complex_fft_analysis(residuals):
    fft_results = fft(residuals)
    frequencies = np.fft.fftfreq(len(fft_results))
    plt.plot(frequencies, np.abs(fft_results))
    plt.title('FFT of Liquid Neural Network Residuals (Complex)')
    plt.show()
    peak_freq_idx = np.argmax(np.abs(fft_results))
    dominant_frequency = frequencies[peak_freq_idx]
    if dominant_frequency == 0:
        warnings.warn("Dominant frequency is zero, setting it to a small non-zero value to avoid division by zero.")
        dominant_frequency = 1e-6
    print(f"Dominant Frequency (Complex): {dominant_frequency}")
    return dominant_frequency

def perform_acf_analysis(residuals):
    plot_acf(residuals)
    plt.show()

def manual_clone_model(model):
    model_copy = Sequential()
    for layer in model.layers:
        if isinstance(layer, RNN):
            rnn_layer = RNN(LiquidLayer(layer.cell.units), return_sequences=layer.return_sequences, input_shape=layer.input_shape[1:])
            model_copy.add(rnn_layer)
        else:
            model_copy.add(layer.__class__.from_config(layer.get_config()))
    model_copy.set_weights(model.get_weights())
    return model_copy

def calculate_learning_curve(model, X_train, y_train, X_val, y_val, batch_size=32, epochs=50, train_sizes=np.linspace(0.1, 1.0, 10)):
    learning_curve_data = []
    for train_size in train_sizes:
        subset_size = int(train_size * X_train.shape[0])
        X_train_subset = X_train[:subset_size]
        y_train_subset = y_train[:subset_size]
        model_clone = manual_clone_model(model)
        model_clone.compile(optimizer=Adam(learning_rate=0.001), loss='mse')
        history = model_clone.fit(X_train_subset, y_train_subset, 
                                  validation_data=(X_val, y_val), 
                                  batch_size=batch_size, 
                                  epochs=epochs, 
                                  verbose=0)
        train_loss = history.history['loss'][-1]
        val_loss = history.history['val_loss'][-1]
        learning_curve_data.append({
            'Train Size': subset_size,
            'Train Loss': train_loss,
            'Validation Loss': val_loss
        })
        print(f"Train size: {subset_size}, Train loss: {train_loss}, Val loss: {val_loss}")
    
    df_learning_curve = pd.DataFrame(learning_curve_data)
    df_learning_curve.to_csv('learning_curve.csv', index=False)
    print("Learning curve data saved to learning_curve.csv")
    
    return df_learning_curve

def generate_predictions(df, window_size, mode='train_test'):
    # Split data into train and validation sets before creating rolling windows
    if mode == 'train_test':
        train_size = int(len(df) * 0.8)
    elif mode == 'production':
        train_size = int(len(df) * 0.9)

    train_df = df.iloc[:train_size]
    val_df = df.iloc[train_size:]

    # Create rolling windows after splitting the data
    X_train, y_train = create_rolling_window_sequences(train_df['Close'].values, window_size)
    X_val, y_val = create_rolling_window_sequences(val_df['Close'].values, window_size)
    
    X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))
    X_val = X_val.reshape((X_val.shape[0], X_val.shape[1], 1))

    input_shape = (X_train.shape[1], X_train.shape[2])
    model = build_liquid_model(input_shape=input_shape)
    history = train_model_with_rolling_window(model, X_train, y_train, X_val, y_val, window_size=window_size, step_size=10, batch_size=32, epochs=50)

    if mode == 'production':
        # Predict 14 days into the future (2 weeks)
        last_window = X_train[-1]  # Get the last window for starting predictions
        predictions = []

        for _ in range(14):  # Predict for the next 14 steps (2 weeks)
            next_pred = model.predict(last_window.reshape(1, window_size, 1)).flatten()[0]
            predictions.append(next_pred)
            last_window = np.roll(last_window, -1)  # Shift the window
            last_window[-1] = next_pred  # Add the prediction as the new input

        future_dates = pd.date_range(start=val_df.index[-1], periods=15, freq='D')[1:]  # 14 future dates
        df_future_predictions = pd.DataFrame({'Date': future_dates, 'LNN_Predictions': predictions})
        df_future_predictions.set_index('Date', inplace=True)
        df = pd.concat([df, df_future_predictions])

    else:
        y_pred = model.predict(X_val).flatten()
        pred_dates = val_df.index[window_size:]  # Match prediction dates to the validation data
        df_predictions = pd.DataFrame(data={'Date': pred_dates, 'LNN_Predictions': y_pred})
        df_predictions.set_index('Date', inplace=True)
        df = df.join(df_predictions, how='left')

    residuals = y_val - y_pred if mode == 'train_test' else np.zeros(len(predictions))  # No residuals in future prediction
    dominant_frequency = perform_complex_fft_analysis(residuals)
    perform_acf_analysis(residuals)

    train_sizes = np.linspace(0.1, 1.0, 10)
    df_learning_curve = calculate_learning_curve(model, X_train, y_train, X_val, y_val, train_sizes=train_sizes)

    try:
        seasonal_order = (1, 1, 1, int(1 / dominant_frequency)) if dominant_frequency != 0 else (1, 1, 1, 1)
        sarima_model = sm.tsa.statespace.SARIMAX(y_train, order=(1, 1, 1), seasonal_order=seasonal_order)
        sarima_results = sarima_model.fit()
        print(sarima_results.summary())
    except Exception as e:
        print(f"Error during SARIMA fitting: {e}")

    return df, df_learning_curve

if __name__ == "__main__":
    df = pd.read_csv('your_data.csv')
    df['Date'] = pd.to_datetime(df['Date'])
    df.set_index('Date', inplace=True)
    window_size = 10
    mode = 'production'  # Switch to production for 2-week prediction
    df_with_predictions, df_learning_curve = generate_predictions(df, window_size, mode)
    print(df_with_predictions.head())
    print(df_learning_curve)
