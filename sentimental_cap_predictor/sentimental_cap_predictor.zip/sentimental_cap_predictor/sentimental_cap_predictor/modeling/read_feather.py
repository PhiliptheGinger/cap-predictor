import pandas as pd

# Load the Feather file
file_path = r'D:\Programming Projects\CAP\sentimental_cap_predictor\sentimental_cap_predictor\data\raw\AAPL_news.feather'
data = pd.read_feather(file_path)

# Display the first few rows and the overall structure of the data
print(data.info())
print(data.head(100))
