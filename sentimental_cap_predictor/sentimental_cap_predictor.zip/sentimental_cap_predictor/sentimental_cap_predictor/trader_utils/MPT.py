from scipy.optimize import minimize

def mean_variance_optimization(expected_returns, cov_matrix, total_funds):
    num_assets = len(expected_returns)
    args = (expected_returns, cov_matrix)
    
    constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1})
    bounds = tuple((0, 1) for _ in range(num_assets))
    
    result = minimize(portfolio_volatility, num_assets*[1./num_assets,], args=args, method='SLSQP', bounds=bounds, constraints=constraints)
    
    allocations = {asset: alloc * total_funds for asset, alloc in zip(expected_returns.keys(), result['x'])}
    return allocations

def portfolio_volatility(weights, expected_returns, cov_matrix):
    return np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))

# Example usage:
expected_returns = {'AAPL': 0.10, 'GOOGL': 0.05, 'MSFT': 0.03}
cov_matrix = np.array([[0.0004, 0.0002, 0.0001], [0.0002, 0.0003, 0.00015], [0.0001, 0.00015, 0.0002]])
total_funds = 10000
allocations = mean_variance_optimization(expected_returns, cov_matrix, total_funds)
print(allocations)
