def proportional_allocation(expected_returns, total_funds):
    total_expected_return = sum(expected_returns.values())
    allocations = {}
    
    for asset, return_pct in expected_returns.items():
        allocations[asset] = (return_pct / total_expected_return) * total_funds
    
    return allocations

# Example usage:
expected_returns = {
    'AAPL': 0.10,
    'GOOGL': 0.05,
    'MSFT': 0.03
}
total_funds = 10000
allocations = proportional_allocation(expected_returns, total_funds)
print(allocations)
