import pandas as pd
import alpaca_trade_api as tradeapi
import numpy as np
import sys
from config import TRADER_DIR

# Ensure that trader_utils is in the Python path
sys.path.append(str(TRADER_DIR))

from proportional_allocation import proportional_allocation 
from sharpe_ratio import sharpe_ratio_allocation
from MPT import mean_variance_optimization

# Load the CSV data
data = pd.read_csv('predictions.csv', parse_dates=['date'])

# Set up Alpaca API with your provided key and endpoint
API_KEY = 'AKSKF4KIG9VH75SEZV95'
API_SECRET = 'your_secret_key'  # Replace this with your secret key, ideally from an environment variable
BASE_URL = 'https://api.alpaca.markets'  # Provided endpoint

api = tradeapi.REST(API_KEY, API_SECRET, BASE_URL, api_version='v2')

# Function to find peaks and valleys
def find_peaks_and_valleys(predictions, window=3):
    peaks = []
    valleys = []
    for i in range(window, len(predictions) - window):
        if predictions[i] > max(predictions[i - window:i]) and predictions[i] > max(predictions[i + 1:i + window + 1]):
            peaks.append(i)
        elif predictions[i] < min(predictions[i - window:i]) and predictions[i] < min(predictions[i + 1:i + window + 1]):
            valleys.append(i)
    return peaks, valleys

# Find peaks and valleys
peaks, valleys = find_peaks_and_valleys(data['LSTM_Predictions'])

# Define stop-loss threshold using a utility from trader_utils (example)
stop_loss_threshold = calculate_stop_loss(data['LSTM_Predictions'])  # Example usage of trader_utils

symbol = 'AAPL'  # Example stock symbol
quantity = 10  # Number of shares to trade

for i in range(len(data)):
    current_price = data['LSTM_Predictions'][i]
    date = data['date'][i]
    
    # Check if there is an open position
    position = None
    try:
        position = api.get_position(symbol)
    except tradeapi.rest.APIError as e:
        pass  # No open position

    if i in valleys and not position:
        # Buy at valley
        print(f"Buying {quantity} shares of {symbol} at ${current_price:.2f} on {date}")
        api.submit_order(
            symbol=symbol,
            qty=quantity,
            side='buy',
            type='market',
            time_in_force='gtc'
        )
    
    elif i in peaks and position:
        # Sell at peak
        print(f"Selling {quantity} shares of {symbol} at ${current_price:.2f} on {date}")
        api.submit_order(
            symbol=symbol,
            qty=quantity,
            side='sell',
            type='market',
            time_in_force='gtc'
        )
    
    elif position and current_price < float(position.avg_entry_price) * stop_loss_threshold:
        # Execute stop-loss
        print(f"Stop-loss triggered: Selling {quantity} shares of {symbol} at ${current_price:.2f} on {date}")
        api.submit_order(
            symbol=symbol,
            qty=quantity,
            side='sell',
            type='market',
            time_in_force='gtc'
        )

# Final check for open positions at the end of the script
try:
    position = api.get_position(symbol)
    if position:
        current_price = data['LSTM_Predictions'].iloc[-1]
        print(f"Closing final position: Selling {quantity} shares of {symbol} at ${current_price:.2f} on {data['date'].iloc[-1]}")
        api.submit_order(
            symbol=symbol,
            qty=quantity,
            side='sell',
            type='market',
            time_in_force='gtc'
        )
except tradeapi.rest.APIError as e:
    pass  # No open position
